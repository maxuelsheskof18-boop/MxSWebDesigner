// WhatsApp local da Máquina de Leads MXS.
// Imita as rotas da Evolution API v2 que a tela usa, então a tela não muda nada:
// basta apontar o "Endereço da Evolution" para http://localhost:8080 com a chave mostrada ao iniciar.
// A sessão do WhatsApp fica na pasta "sessao" (não compartilhe essa pasta).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import makeWASocket, { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } from '@whiskeysockets/baileys';
import QRCode from 'qrcode';
import pino from 'pino';

const PASTA = path.dirname(fileURLToPath(import.meta.url));
const PASTA_SESSAO = path.join(PASTA, 'sessao');
const ARQ_CONFIG = path.join(PASTA, 'config.json');

// Chave criada na primeira vez: sem ela, qualquer site aberto no navegador poderia mandar mensagens por aqui.
function lerConfig() {
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(ARQ_CONFIG, 'utf8')); } catch { /* primeira vez */ }
  if (!cfg.chave) cfg.chave = crypto.randomBytes(12).toString('hex');
  if (!cfg.porta) cfg.porta = 8080;
  fs.writeFileSync(ARQ_CONFIG, JSON.stringify(cfg, null, 2));
  return cfg;
}
const config = lerConfig();

// ----------------------------- WhatsApp -----------------------------
let sock = null;
let estado = 'close';      // close | connecting | open
let qrAtual = null;        // data URL do QR enquanto espera leitura
let iniciando = null;

// Só conta como sessão depois que o QR foi lido (o creds.json nasce antes, ainda sem o número em "me").
function temSessao() {
  try {
    return Boolean(JSON.parse(fs.readFileSync(path.join(PASTA_SESSAO, 'creds.json'), 'utf8')).me);
  } catch {
    return false;
  }
}

async function iniciarWhatsApp() {
  if (iniciando) return iniciando;
  iniciando = (async () => {
    const { state, saveCreds } = await useMultiFileAuthState(PASTA_SESSAO);
    const { version } = await fetchLatestBaileysVersion().catch(() => ({ version: undefined }));
    estado = 'connecting';
    sock = makeWASocket({
      version,
      auth: state,
      logger: pino({ level: 'silent' }),
      browser: Browsers.windows('MXS Leads'),
      markOnlineOnConnect: false,
      syncFullHistory: false
    });
    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        qrAtual = await QRCode.toDataURL(qr, { margin: 1, width: 320 });
        estado = 'connecting';
        console.log('QR code novo gerado — leia pela tela da MXS.');
      }
      if (connection === 'open') {
        estado = 'open';
        qrAtual = null;
        console.log(`✓ WhatsApp conectado (${sock.user?.id?.split(':')[0] || 'número'}).`);
      }
      if (connection === 'close') {
        const codigo = lastDisconnect?.error?.output?.statusCode;
        estado = 'close';
        qrAtual = null;
        sock = null;
        iniciando = null;
        if (codigo === DisconnectReason.loggedOut) {
          fs.rmSync(PASTA_SESSAO, { recursive: true, force: true });
          console.log('Número desconectado. Para voltar, leia o QR code de novo.');
          return;
        }
        // Queda de rede ou QR expirado sem leitura: só reconecta sozinho se já havia sessão.
        if (temSessao()) {
          console.log(`Conexão caiu (código ${codigo ?? '?'}). Reconectando…`);
          setTimeout(() => iniciarWhatsApp().catch(e => console.error(e.message)), 3000);
        }
      }
    });
  })();
  return iniciando;
}

async function esperarQr(ms = 15000) {
  const fim = Date.now() + ms;
  while (Date.now() < fim && !qrAtual && estado !== 'open') await new Promise(r => setTimeout(r, 300));
  return qrAtual;
}

function exigirConectado() {
  if (estado !== 'open' || !sock) {
    const e = new Error('WhatsApp não está conectado. Leia o QR code pela tela da MXS.');
    e.status = 400;
    throw e;
  }
}

const jidDe = numero => String(numero).replace(/\D/g, '') + '@s.whatsapp.net';
const esperar = ms => new Promise(r => setTimeout(r, ms));

// ----------------------------- HTTP -----------------------------
const rotas = [
  ['GET', /^\/instance\/connectionState\/[^/]+$/, async () =>
    ({ instance: { instanceName: 'mxs', state: estado } })],

  // A tela chama "create" quando a instância não existe; aqui ela sempre existe, mas atende igual.
  ['POST', /^\/instance\/create$/, async () => {
    if (estado !== 'open') { await iniciarWhatsApp(); await esperarQr(); }
    return { qrcode: { base64: qrAtual } };
  }],

  ['GET', /^\/instance\/connect\/[^/]+$/, async () => {
    if (estado !== 'open') { await iniciarWhatsApp(); await esperarQr(); }
    return { base64: qrAtual };
  }],

  ['DELETE', /^\/instance\/logout\/[^/]+$/, async () => {
    if (sock) await sock.logout().catch(() => {});
    fs.rmSync(PASTA_SESSAO, { recursive: true, force: true });
    estado = 'close';
    return { status: 'SUCCESS' };
  }],

  ['POST', /^\/chat\/whatsappNumbers\/[^/]+$/, async corpo => {
    exigirConectado();
    const lista = [];
    for (const numero of corpo.numbers || []) {
      const [r] = await sock.onWhatsApp(jidDe(numero)).catch(() => []);
      lista.push({ exists: Boolean(r?.exists), jid: r?.jid || jidDe(numero), number: String(numero) });
    }
    return lista;
  }],

  ['POST', /^\/message\/sendText\/[^/]+$/, async corpo => {
    exigirConectado();
    const jid = jidDe(corpo.number);
    if (corpo.delay) {
      await sock.sendPresenceUpdate('composing', jid).catch(() => {});
      await esperar(Math.min(Number(corpo.delay) || 0, 10000));
      await sock.sendPresenceUpdate('paused', jid).catch(() => {});
    }
    const msg = await sock.sendMessage(jid, { text: String(corpo.text || '') });
    console.log(`→ mensagem enviada para ${corpo.number}`);
    return { key: msg?.key };
  }],

  ['POST', /^\/message\/sendMedia\/[^/]+$/, async corpo => {
    exigirConectado();
    if (corpo.mediatype !== 'document') throw Object.assign(new Error('Só documentos (PDF) são aceitos aqui.'), { status: 400 });
    const msg = await sock.sendMessage(jidDe(corpo.number), {
      document: Buffer.from(String(corpo.media || ''), 'base64'),
      mimetype: corpo.mimetype || 'application/pdf',
      fileName: corpo.fileName || 'documento.pdf',
      caption: corpo.caption || undefined
    });
    console.log(`→ PDF ${corpo.fileName} enviado para ${corpo.number}`);
    return { key: msg?.key };
  }]
];

function responder(res, status, dados) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(dados));
}

const servidor = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'apikey, content-type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.end();

  const url = req.url.split('?')[0];
  if (req.method === 'GET' && url === '/') {
    return responder(res, 200, { servico: 'WhatsApp local MXS', estado });
  }
  if (req.headers.apikey !== config.chave) {
    return responder(res, 401, { response: { message: 'API key inválida' } });
  }
  const rota = rotas.find(([m, re]) => m === req.method && re.test(url));
  if (!rota) return responder(res, 404, { response: { message: `Rota não existe: ${url}` } });

  let tamanho = 0;
  const partes = [];
  req.on('data', p => {
    tamanho += p.length;
    if (tamanho > 25 * 1024 * 1024) req.destroy();
    else partes.push(p);
  });
  req.on('end', async () => {
    try {
      const texto = Buffer.concat(partes).toString('utf8');
      responder(res, 200, await rota[2](texto ? JSON.parse(texto) : {}));
    } catch (e) {
      responder(res, e.status || 500, { response: { message: e.message } });
    }
  });
});

servidor.listen(config.porta, '127.0.0.1', () => {
  console.log('');
  console.log('  ===============  WhatsApp local MXS  ===============');
  console.log(`  Endereço:  http://localhost:${config.porta}`);
  console.log(`  API key:   ${config.chave}`);
  console.log('  Instância: mxs');
  console.log('  Deixe esta janela aberta enquanto estiver enviando.');
  console.log('  ====================================================');
  console.log('');
  if (temSessao()) iniciarWhatsApp().catch(e => console.error('Erro ao conectar:', e.message));
});

servidor.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`A porta ${config.porta} já está em uso — o WhatsApp local já está aberto em outra janela?`);
  else console.error(e);
  process.exitCode = 1;
});
