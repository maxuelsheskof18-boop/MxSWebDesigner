@echo off
chcp 65001 >nul
title WhatsApp local MXS
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando na primeira vez, aguarde...
  call npm install --omit=dev --no-audit --no-fund
)
start "" "%~dp0..\index.html"
node servidor.js
pause
